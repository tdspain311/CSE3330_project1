<?php
$servername = "omega.uta.edu";
$username = "trd7801";
$password = "testing";

// Create connection
$conn = new mysqli($servername, $username, $password);
?>