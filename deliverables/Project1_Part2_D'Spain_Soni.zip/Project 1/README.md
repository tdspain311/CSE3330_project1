CSE 3330:	Project 1

Developers: 	Isha Soni
	        Tyler D�Spain

Web Server: 	Apache
Language: 	PHP
Database: 	MySQL

Description: 	
Load index.html in localhost.  To test correct php version select PHP test, version used in development 5.6.10.  MySQL and MySQLi extensions should be enabled in php settings.  
Problems 1, 2 and 3 were done in php to create the database, create the tables, load the data and query the database.  Spool files were generated using MySQL workbench with data export.  Problems 4, 5, 6 were done in omega using sqlloader to generate the necessary spool files to obtain the INSERT, UPDATE and DELETE functionality.

All query php files are located in the �query� directory
All table loaders and located in the �loaders� directory
All files pertaining to omega are located in the �SQLloader� directory
